<?php namespace App\Models;

    use CodeIgniter\Model;

    class Category extends Model {

        protected $table      = 'categories';
        protected $primaryKey = 'category_id';

        protected $allowedFields = ['name_category'];

        protected $useSoftDeletes = true;

        protected $useTimestamps = true;
        protected $createdField  = 'created_at';
        protected $updatedField  = 'updated_at';
        protected $deletedField  = 'deleted_at';

        protected $returnType = 'array';

        public function showCategories()
        {
            return $this->findAll();
        }

        public function newCategory($nameCategory)
        {
            $data = ['name_category' => $nameCategory];
            $this->insert($data);
        }

        public function deleteCategory($category_id)
        {
            $this->delete($category_id);
        }

    }