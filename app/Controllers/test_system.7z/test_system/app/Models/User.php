<?php namespace App\Models;

    use CodeIgniter\Model;

    class User extends Model {

        protected $table      = 'users';
        protected $primaryKey = 'user_id';

        protected $allowedFields = ['name', 'surname', 'middlename', 'email', 'phone', 'password', 'role'];

        protected $returnType = 'array';

        public function sigIn($login, $password)
        {
            return $this->where(['login' => $login, 'password' => $password])->first();
        }

        public function newUser($name, $surname, $middlename, $email, $phone, $login, $password)
        {
            $data = [
                'name' => $name,
                'surname' => $surname,
                'middlename' => $middlename,
                'email' => $email,
                'phone' => $phone,
                'login' => $login,
                'password' => $password,
                'role' => 0
            ];

            $this->insert($data);
            return $this->where(['user_id' => $this->insertID()])->first();
        }



    }
