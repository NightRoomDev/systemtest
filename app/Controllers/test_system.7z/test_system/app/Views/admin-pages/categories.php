
    <?= $this->include('templates/header'); ?>
    <body style="background: url(https://html5book.ru/wp-content/uploads/2015/06/background28.jpg)">
    <?= $this->include('templates/navbar-admin'); ?>
    <div id="modal1" class="modal">
        <div class="modal-content">
            <div class="row">
                <div class="col s12">
                    <h4>Новая категория</h4>
                </div>
            </div>
            <form class="row" method="POST" action="">
                <div class="col s12">
                    <div class="row modal-form-row">
                        <div class="input-field col s12">
                            <input id="name_category" type="text" name="name_category" class="name_category validate">
                            <label for="name_category">Название категории</label>
                        </div>
                    </div>   
                </div>
                <div class="col s12">
                    <button type="submit" class="waves-effect waves-light btn">Создать</button>
                </div>   
            </form>
        </div>
      
    </div>
    <div class="container">
        <div class="row space-top-m">
            <div class="col s12 white space-all-p" style="border-radius: 3px">
                <h5>Категории</h5>
                <button class="waves-effect waves-light btn modal-trigger" data-target="modal1"><i class="fas fa-plus" style="margin-right: 7px"></i>Создать</button>
                <button class="waves-effect waves-light btn"><i class="fas fa-undo-alt" style="margin-right: 7px"></i>Восстановить записи</button>
                <button class="waves-effect waves-light btn"><i class="far fa-trash-alt" style="margin-right: 7px"></i>Удаленные записи</button>
            </div>
        </div>
        <div class="row">
            <div class="col s12 white space-all-p" style="border-radius: 3px">
            <table class="highlight">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Название категории</th>
                        <th>Удалить / Редактировать</th>
                        <th>Просмотр</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach($showCategories as $item): ?>
                    <tr>
                        <td><?=$item['category_id'];?></td>
                        <td><?=$item['name_category'];?></td>
                        <td>
                            <a href="#" class="waves-effect waves-light btn green btn-small"><i class="fas fa-edit"></i></a>
                            <a href="/admin/delete/<?=$item['category_id']?>" class="waves-effect waves-light btn red btn-small"><i class="fas fa-trash-alt"></i></a>
                        </td>
                        <td>
                            <a href="#" class="waves-effect waves-light btn green btn-small tooltipped" data-position="right" data-tooltip="Все тесты по данной категории"><i class="fas fa-eye"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <?= $this->include('templates/action_btn'); ?>
    <?= $this->include('templates/footer'); ?>

