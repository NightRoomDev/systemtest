
    <?= $this->include('templates/header'); ?>
    <?= $this->include('templates/navbar-admin'); ?>

    <div class="container">
        <div class="row">
            <div class="col-12">
                Admin!
            </div>
        </div>
    </div>

    <?= $this->include('templates/footer'); ?>

