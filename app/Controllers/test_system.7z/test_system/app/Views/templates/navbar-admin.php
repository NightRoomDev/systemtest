<nav>
    <div class="nav-wrapper blue darken-4">
        <div class="container">
            <ul id="nav-mobile" class="left hide-on-med-and-down">
                <li data-target="slide-out" class="sidenav-trigger"><a href="#"><i class="fas fa-bars"></i></a></li>
            </ul>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a href="/admin/categories/">Категории</a></li>
                <li><a href="badges.html">Тесты</a></li>
                <li><a href="collapsible.html">Статистика</a></li>
                <li><a href="/logOff"><i class="fas fa-door-open"></i></a></li>
            </ul>
        </div>
    </div>
</nav>


<ul id="slide-out" class="sidenav">
    <li><div class="user-view">
            <div class="background">
                <img src="https://img3.goodfon.ru/wallpaper/nbig/2/59/minimalizm-zakat-fon-gory.jpg" style="height: 200px">
            </div>
            <a href="#user"><img class="circle" src="https://sun9-68.userapi.com/c638530/v638530136/5df56/HCxq7aFxuAQ.jpg"></a>
            <a href="#name"><span class="white-text name">Kosyak Evnegiy</span></a>
            <a href="#email"><span class="white-text email">SweetHeartSeven@yandex.ru</span></a>
        </div></li>
    <li><a href="#!">Профиль</a></li>
    <li><a href="#!">Настройка панели</a></li>
    <li><div class="divider"></div></li>
    <li><a class="waves-effect">Тесты</a></li>
    <li><a class="waves-effect" href="/admin/categories/">Категории</a></li>
    <li><a class="waves-effect" href="#!">Пользователи</a></li>
    <li><a class="waves-effect" href="#!">Выйти</a></li>
</ul>

<script>

    $(document).ready(function(){

        $('.sidenav').sidenav();
        $('.tooltipped').tooltip();
        $('.fixed-action-btn').floatingActionButton();
        $('.modal').modal();

    });





</script>