
  <?= $this->include('templates/header'); ?>
  <body class="bg-page">
  <div class="container">
    <div class="row mt-2 pt-5">
      <div class="col-4 m-auto pt-3">
        <img src="<?=base_url()?>/img/logo.png" width="160" class="d-block m-auto pb-5" alt="">
        <form action="" class="needs-validation bg-white pt-4 pb-5 pl-5 pr-5 shadow" method="POST" novalidate>
          <h3 class="text-center mt-4 mb-5">Вход</h3>
            <?php if($error_message != ''): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?=$error_message?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
          <hr>
          <div class="form-row mt-3 mb-4">
            <input type="text" class="form-control" name="login" placeholder="Логин или email" required>
              <div class="invalid-feedback">
                  Введите логин.
              </div>
          </div>
          <div class="form-row mb-3">
            <input type="password" class="form-control" name="password" placeholder="Пароль" required>
              <div class="invalid-feedback">
                  Введите пароль.
              </div>
          </div>
            <div class="form-row mb-3">
                <a href="">Забыли пароль?</a>
            </div>
          <div class="form-row">
              <button type="submit" class="btn btn-outline-primary w-100"><i class="fas fa-sign-in-alt mr-2"></i>Войти</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <?= $this->include('templates/footer'); ?>
