
<?= $this->include('templates/header'); ?>
<body>
<?= $this->include('templates/navbar'); ?>

<div class="container-fluid">
    <div class="container">
        <div class="col-12">
            <h1>Список категорий</h1>
        </div>
    </div>
</div>

<?= $this->include('templates/footer'); ?>
