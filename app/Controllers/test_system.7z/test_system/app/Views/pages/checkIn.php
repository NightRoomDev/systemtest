
<?= $this->include('templates/header'); ?>
<body class="bg-page">
<div class="container">
    <div class="row mt-2 pt-5">
        <div class="col-6 m-auto pt-3">
            <img src="<?=base_url()?>/img/logo.png" width="160" class="d-block m-auto pb-5" alt="">
            <form action="/checkIn" class="needs-validation bg-white pt-4 pb-5 pl-5 pr-5 shadow" method="POST" novalidate>
            <h3 class="text-center mt-4 mb-5">Регистрация</h3>
                <hr>
                <div class="form-row mt-3 mb-4">
                    <div class="col-4 pl-0">
                        <input type="text" class="form-control" name="surname" placeholder="Фамилия" required>
                        <div class="invalid-feedback">
                            Введите фамилю.
                        </div>
                    </div>
                    <div class="col-4">
                        <input type="text" class="form-control" name="name" placeholder="Имя" required>
                        <div class="invalid-feedback">
                            Введите имя.
                        </div>
                    </div>
                    <div class="col-4 pr-0">
                        <input type="text" class="form-control" name="middlename" placeholder="Отчество" required>
                        <div class="invalid-feedback">
                            Введите отчество.
                        </div>
                    </div>
                </div>
                <div class="form-row mt-3 mb-4">
                    <input type="email" class="form-control" name="email" placeholder="email" required>
                    <div class="invalid-feedback">
                        Введите свой email.
                    </div>
                </div>
                <div class="form-row mb-3">
                    <input type="text" class="form-control" name="phone" placeholder="Номер телефона" required>
                    <div class="invalid-feedback">
                        Введите свой номер телефона.
                    </div>
                </div>
                <div class="form-row mb-3">
                    <input type="text" class="form-control" name="login" placeholder="Логин" required>
                    <div class="invalid-feedback">
                        Введите логин.
                    </div>
                </div>
                <div class="form-row mb-3">
                    <div class="col-6 pl-0">
                        <input type="password" class="form-control" name="password" placeholder="Пароль" required>
                        <div class="invalid-feedback">
                            Введите пароль.
                        </div>
                    </div>
                    <div class="col-6 pr-0">
                        <input type="password" class="form-control" name="password" placeholder="Повторите пароль" required>
                        <div class="invalid-feedback">
                            Повторите пароль.
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <button type="submit" class="btn btn-outline-primary w-100"><i class="fas fa-sign-in-alt mr-2"></i>Зарегистрироваться</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->include('templates/footer'); ?>
