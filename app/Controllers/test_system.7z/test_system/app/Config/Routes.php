<?php namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php'))
{
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index'); // Page index
$routes->add('/sigin/', 'Home::sigin'); // Page auth
$routes->add('/checkIn/', 'Home::checkIn'); // Page regist
$routes->get('/aboutProject/', 'Home::aboutProject'); // Page about
$routes->get('/categories/', 'Home::categories'); // Page categories to Home controller
$routes->get('/logOff/', 'Home::logOff'); // method exit

$routes->add('/admin/', 'Admin::index'); // Panel control admin
$routes->add('/admin/categories/', 'Admin::categories'); // Page categories to Admin controller
$routes->get('/admin/delete/(:num)', 'Admin::deleteCategory'); // Method del category
$routes->add('/admin/tests/', 'Admin::tests'); // Page tests
$routes->add('/admin/users/', 'Admin::users'); // Page users
$routes->add('/admin/user/(:num)', 'Admin::user'); // Page one user

/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need to it be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php'))
{
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
