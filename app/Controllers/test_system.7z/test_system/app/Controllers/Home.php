<?php namespace App\Controllers;

    use App\Models\User;
    use CodeIgniter\HTTP\RequestInterface;

    class Home extends BaseController
    {
        public $user;
        public $session;

        public function __construct()
        {
            $this->user = new User();
            $this->session = \Config\Services::session();
            helper('form');
        }

        public function index()
        {
            $data['title'] = 'Главная';
            $data['cssLibrary'] = 'bootstrap.min.css';
            return view('pages/index', $data);
        }

        public function aboutProject()
        {
            $data['title'] = 'О проекте';
            $data['cssLibrary'] = 'bootstrap.min.css';
            return view('pages/about-project', $data);
        }

        public function categories()
        {
            $data['title'] = 'Категории';
            $data['cssLibrary'] = 'bootstrap.min.css';
            return view('/pages/categories', $data);
        }

        public function sigin()
        {
            $data['title'] = 'Войти';
            $data['cssLibrary'] = 'bootstrap.min.css';
            $data['error_message'] = '';

            if (!empty($_POST)) {

                $data['sigIn'] = $this->user->sigIn($this->request->getVar('login'), $this->request->getVar('password'));

                if (!empty($data['sigIn']))
                {
                    $userdata = [
                        'id' => $data['sigIn']['user_id'],
                        'name' => $data['sigIn']['name'],
                        'surname' => $data['sigIn']['surname'],
                        'middlename' => $data['sigIn']['middlename']
                    ];

                    $this->session->set($userdata);

                    if ($data['sigIn']['role'] == 1) {
                        return redirect()->route('admin');
                    }
                    else {
                        return redirect()->to('/user/');
                    }
                } else {
                    $this->session->setFlashdata('error_message', 'Пользователь не найден.');
                    $data['error_message'] = $this->session->getFlashdata('error_message');
                }

            }

            return view('pages/sigin', $data);
        }

        public function checkIn()
        {
            $data['title'] = 'Регистрациия';
            $data['cssLibrary'] = 'bootstrap.min.css';

            if (!empty($_POST)) 
            {

                $data['newUser'] = $this->user->newUser(
                    $this->request->getVar('name'),
                    $this->request->getVar('surname'),
                    $this->request->getVar('middlename'),
                    $this->request->getVar('email'),
                    $this->request->getVar('phone'),
                    $this->request->getVar('login'),
                    $this->request->getVar('password')
                );

                // if (!empty($data['newUser'])) {

                //     $userdata = [
                //         'id' => $data['newUser'],
                //         'name' => $this->request->getVar('name'),
                //         'surname' => $this->request->getVar('surname'),
                //         'middlename' => $this->request->getVar('middlename')
                //     ];

                // }

                var_dump($data['newUser']);

            }

            return view('pages/checkIn', $data);
        }

        public function logOff()
        {
            $this->session->destroy();
            return redirect()->route('/');
        }

    }

        //----------------------------------------------------------------