<?php namespace App\Controllers;

    use CodeIgniter\Controller;
    use App\Models\Category;

    class Admin extends BaseController {

        public $category;
        public $session;

        public function __construct()
        {
            $this->category = new Category();
            $this->session = \Config\Services::session();
            helper('form');
        }

        public function index()
        {
            $data['title'] = 'Панель управления - главная';
            $data['cssLibrary'] = 'materialize.min.css';
            return view('admin-pages/index', $data);
        }

        public function categories()
        {
            $data['title'] = 'Панель управления - категории';
            $data['cssLibrary'] = 'materialize.min.css';
            $data['message'] = '';

            if (!empty($_POST))
            {
                $data['newCategory'] = $this->category->newCategory($this->request->getVar('name_category'));
                $data['message'] = $this->session->setFlashdata('success', 'Новая категория добавлена');
            }

            $data['showCategories'] = $this->category->showCategories();

            return view('admin-pages/categories', $data);
        }

        public function deleteCategory()
        {
           $data['deleteCategory'] = $this->category->deleteCategory($this->request->uri->getSegment(3));
           return redirect()->to('/admin/categories/');
        }

    }
